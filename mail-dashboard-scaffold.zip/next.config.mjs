/** @type {import('next').NextConfig} */
const nextConfig = {
  experimental: {
    serverActions: false,
    jsconfigPaths: true
  }
};
export default nextConfig;
